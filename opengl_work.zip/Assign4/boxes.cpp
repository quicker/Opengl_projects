#ifndef INC
#include <GL/gl.h>
#include <GL/glu.h> 
#include <GL/glut.h>
#include <cmath>
#include <ctime>
#endif
//#include "glm/glm.h"
#define SENSITIVITY 0.6
#define CARFILE "policecar.obj"
class SlidingBox
{
  double x, y, z, l, w, h;         // x, y and z are the coordinates of the center of the cuboid of length l, width w and height h.
  double R, G, B, A;
  bool movable, ismoving;          // l is in dimension of x, w in dimension of z and h in dimension of y.
  public:
  SlidingBox()
  {
    l = w = h = 0;
  }
  void initialize(double xx, double yy, double zz, double len, double ht, double wid, bool mov = true)
  {
    x = xx;
    y = yy;
    z = zz;
    w = wid;
    h = ht;
    l = len;
    movable = mov;
  }
  void setColor(double red, double green, double blue, double alpha)
  {
    R = red;
    G = green;
    B = blue;
    A = alpha;
  }
  void draw()
  {
    glPushMatrix();
      glTranslated(x, y, z);
     // printf("drawing at %lf %lf %lf - %lf %lf %lf\n", x, y, z, l, h, w);
      //glPolygonMode(GL_FRONT, GL_FILL);
      //glColor4d(140.0/255, 140.0/255, 140.0/255, 1);      // some greyish color
      glColor4d(R, G, B, A);
      glBegin(GL_QUADS);
        glVertex3d(x - l/2, y - h/2, z - w/2);
        glVertex3d(x - l/2, y + h/2, z - w/2);
        glVertex3d(x + l/2, y + h/2, z - w/2);
        glVertex3d(x + l/2, y - h/2, z - w/2);
      glEnd();
      glBegin(GL_QUADS);
        glVertex3d(x - l/2, y - h/2, z + w/2);
        glVertex3d(x - l/2, y + h/2, z + w/2);
        glVertex3d(x + l/2, y + h/2, z + w/2);
        glVertex3d(x + l/2, y - h/2, z + w/2);
      glEnd();
      glBegin(GL_QUADS);
        glVertex3d(x - l/2, y - h/2, z - w/2);
        glVertex3d(x - l/2, y + h/2, z - w/2);
        glVertex3d(x - l/2, y + h/2, z + w/2);
        glVertex3d(x - l/2, y - h/2, z + w/2);
      glEnd();
      glBegin(GL_QUADS);
        glVertex3d(x + l/2, y - h/2, z - w/2);
        glVertex3d(x + l/2, y + h/2, z - w/2);
        glVertex3d(x + l/2, y + h/2, z + w/2);
        glVertex3d(x + l/2, y - h/2, z + w/2);
      glEnd();
      glBegin(GL_QUADS);
        glVertex3d(x - l/2, y - h/2, z - w/2);
        glVertex3d(x - l/2, y - h/2, z + w/2);
        glVertex3d(x + l/2, y - h/2, z + w/2);
        glVertex3d(x + l/2, y - h/2, z - w/2);
      glEnd();
      glBegin(GL_QUADS);
        glVertex3d(x - l/2, y + h/2, z - w/2);
        glVertex3d(x - l/2, y + h/2, z + w/2);
        glVertex3d(x + l/2, y + h/2, z + w/2);
        glVertex3d(x + l/2, y + h/2, z - w/2);
      glEnd();
    glPopMatrix();
  }
};

class Car
{
  public:
  double zslider, r, zinc, lightfi, wheelR, l, w, h;
  double wheelTheta, steerTheta;    // all in degrees.
  bool ismoving, movable;
  int turning;
  GLenum searchl, headl1, headl2;
  double seat;
  GLMmodel *model;
  Car()
  {
    zslider = 0.0;
    zinc = 1;
    lightfi = 0;
    seat = 0.3;
    movable = true;
    wheelTheta = steerTheta = 0;
    r = 0.8;
    l = 10; w = 4; h = 1;
    wheelR = r;
  }
  void bindlights(GLenum g3, GLenum g1, GLenum g2)
  {
	  headl1 = g1;
	  headl2 = g2;
	  searchl = g3;
  }
  void loadmodel()
  {
    model = glmReadOBJ(CARFILE);
    glmUnitize(model);
    glmFacetNormals(model);
    glmVertexNormals(model, 90.0, true);
  }
  void incWheelTheta(double inc)
  {
    wheelTheta += inc;
  }
  void turn(double inc)
  {
    if(steerTheta*inc < 0 || fabs(steerTheta) <= 20)
      steerTheta += inc*SENSITIVITY;
  }
  double driver_head()
  {
    return seat + 0.3;
  }
  double roof()
  {
    return 0.8;
  }
  double slider()
  {
    return zslider;
  }
  void drawWheel(double inr, double outr, int spokes, double theta)
  {
    GLUquadric* q = gluNewQuadric();
    gluQuadricDrawStyle(q, GLU_FILL);
    glPushMatrix();
      glRotated(theta, 0, 0, 1);
      glutSolidTorus(inr, outr, 100, 100);
      glutSolidSphere(0.16, 10, 10);
      glPushMatrix();
        glRotated(90, 0, 1, 0);
        double step = 360.0/(1.0*spokes);
        for(int i = 0; i < spokes; i++)
        {
          glPushMatrix();
            glRotated(i*step, 1, 0, 0);
            gluCylinder(q, inr*0.2, inr*0.2, outr, 20, 20);
          glPopMatrix();
        }
      glPopMatrix();
    glPopMatrix();
    gluDeleteQuadric(q);
  }
  /*
  void place(double X, double Y, double Z, double fi)
  {
    x = X;
    y = Y;
    z = Z;
    theta = 180.0*fi/M_PI;
  }*/
  void draw()
  {
    GLUquadric* gq = gluNewQuadric();
    gluQuadricDrawStyle(gq, GLU_FILL);
    glPushMatrix();
     glTranslated(0, 0.8*h + r + w/15, 0);
     glPushMatrix();
       glTranslatef(0, 0.4, 0);
       glScalef(6, 6, 6);
       glmDraw(model, GLM_SMOOTH | GLM_TEXTURE | GLM_MATERIAL);
     glPopMatrix();
     // headlights
     glPushMatrix();
       glTranslatef(l/1.75 + 0.05, -0.22*h, w/2.8);
       GLfloat ycol[] = {204.0/255, 119.0/255, 34.0/255, 1};
       GLfloat hlcol[] = {204.0/255, 17.0/255, 0, 1};
       GLfloat white[] = {1, 1, 1, 1};
       float hll = 0.9, hlh = 0.6;
       glMaterialfv(GL_FRONT, GL_EMISSION, ycol);
       glMaterialfv(GL_FRONT, GL_AMBIENT, ycol);
       glMaterialfv(GL_FRONT, GL_DIFFUSE, hlcol);
       glBegin(GL_QUADS);
         glVertex3f(0, -hlh/2, -hll/2);
         glVertex3f(0, -hlh/2, hll/2);
         glVertex3f(0, hlh/2, hll/2);
         glVertex3f(0, hlh/2, -hll/2);
       glEnd();
       glNormal3f(1, 0, 0);
       GLfloat xaxis[]= {1, -0.3, 0, 1};
       GLfloat zero[] = {0, 0, 0, 1};
       glLightfv(headl1, GL_DIFFUSE, hlcol);
       glLightfv(headl1, GL_SPOT_DIRECTION, xaxis);
       glLightf(headl1, GL_SPOT_CUTOFF, 30);
       glLightfv(headl1, GL_POSITION, zero);
       GLfloat tmp[] = {0, 0, 0, 1};
       glMaterialfv(GL_FRONT, GL_EMISSION, tmp);
       glMaterialfv(GL_FRONT, GL_AMBIENT, white);
       glMaterialfv(GL_FRONT, GL_DIFFUSE, white);
     glPopMatrix();
     
     glPushMatrix();
       glTranslatef(l/1.75 + 0.05, -0.22*h, -w/2.8);
       //GLfloat ycol[] = {204.0/255, 119.0/255, 34.0/255, 1};
       //float hll = 0.9, hlh = 0.6;
       glMaterialfv(GL_FRONT, GL_EMISSION, ycol);
       glMaterialfv(GL_FRONT, GL_AMBIENT, ycol);
       glMaterialfv(GL_FRONT, GL_DIFFUSE, hlcol);
       glBegin(GL_QUADS);
         glVertex3f(0, -hlh/2, -hll/2);
         glVertex3f(0, -hlh/2, hll/2);
         glVertex3f(0, hlh/2, hll/2);
         glVertex3f(0, hlh/2, -hll/2);
       glEnd();
       glNormal3f(1, 0, 0);
       glLightfv(headl2, GL_DIFFUSE, hlcol);
       glLightfv(headl2, GL_SPOT_DIRECTION, xaxis);
       glLightf(headl2, GL_SPOT_CUTOFF, 30);
       glLightfv(headl2, GL_POSITION, zero);
       //GLfloat tmp[] = {0, 0, 0, 1};
       //GLfloat white[] = {1, 1, 1, 1};
       glMaterialfv(GL_FRONT, GL_EMISSION, tmp);
       glMaterialfv(GL_FRONT, GL_AMBIENT, white);
       glMaterialfv(GL_FRONT, GL_DIFFUSE, white);
     glPopMatrix();
     // end of headlights
     
     //SlidingBox B1;
     //B1.initialize(0, 0, 0, l, h, w);
     //B1.setColor(132.0/255, 112.0/255, 1, 1);
     //B1.draw();
     glPushMatrix();
      glTranslated(0.4*l , 2*h/3.0, 0);
     // SlidingBox B2;
     // B2.initialize(0, 0, 0, l/6, h/3, w);
     // B2.setColor(0/255, 62.0/255, 1, 0);
     // B2.draw();
      /*
      glPushMatrix();
       glTranslated(0, h/6, w/4);
       glColor4d(93.0/255, 71.0/255, 139.0/255, 1);
       glRotated(-90, 0, 1, 0);
       glRotated(-30, 1, 0, 0);
       gluCylinder(gq, 0.01, 0.01, l/10, 5, 5);
       glPushMatrix();
        glTranslated(0, 0, l/12);
        drawWheel(0.02, w/6, 3, steerTheta*2);
       glPopMatrix();
      glPopMatrix();
     */
     glPopMatrix();
     glPushMatrix();
      glTranslated(-0.1*l, h, 5.0*w/12.0);
     // SlidingBox P1;
     // P1.initialize(0, 0, 0, l/9, h, w/6);
     // P1.setColor(0, 97.0/255, 28.0/255, 1);
     // P1.draw();
     glPopMatrix();
     glPushMatrix();
      glTranslated(-0.1*l, h, -5.0*w/12.0);
     // SlidingBox P2;
     // P2.initialize(0, 0, 0, l/9, h, w/6);
     // P2.setColor(0, 97.0/255, 28.0/255, 1);
     // P2.draw();
     glPopMatrix();
     // start tyres.
     glColor3d(97.0/255, 97.0/255, 97.0/255);
     glPushMatrix();
      glTranslated(-1*(0.4*l - r + 1.35), -0.8*h, w/2 - 0.4);
      gluCylinder(gq, w/20, w/20, w/20, 4, 4);
      glTranslated(0, 0, w/20);
      drawWheel(w/15 + 0.14, r - 0.1, 10, wheelTheta);
     glPopMatrix();
     glPushMatrix();
      glTranslated(-1*(0.4*l - r + 1.35), -0.8*h, -1*w/2 + 0.4);
      //glRotated(180, 0, 1, 0);
      gluCylinder(gq, w/20, w/20, w/20, 4, 4);
      glTranslated(0, 0, -w/20);
      drawWheel(w/15 + 0.14, r - 0.1, 10, wheelTheta);
     glPopMatrix();
     glPushMatrix();
      glTranslated((0.4*l - r + 1.30), -0.8*h, w/2.0 - 0.4);
      gluCylinder(gq, w/20, w/20, w/20, 4, 4);
      glTranslated(0, 0, w/20);
      glRotated(steerTheta, 0, 1, 0);
      drawWheel(w/15 + 0.13, r - 0.2, 10, wheelTheta);
     glPopMatrix();
     glPushMatrix();
      glTranslated((0.4*l - r + 1.30), -0.8*h, -1*w/2.0 + .4);
      gluCylinder(gq, w/20, w/20, -1*w/20, 4, 4);
      glTranslated(0, 0, -1*w/20);
      glRotated(steerTheta, 0, 1, 0);
      drawWheel(w/15 + 0.13, r - 0.2, 10, wheelTheta);
     glPopMatrix();
     // end of tyres
     
     glPushMatrix();
      glTranslated(-0.1*l, 1.6*h, 0);
      //SlidingBox rail;
      //rail.initialize(0, 0, 0, l/5, h/5, w);
      //rail.setColor(50.0/255, 50.0/255, 50.0/255, 1);
      //rail.draw();
      glPushMatrix();
       zslider = zslider + (zinc)*0.01;
       if(zslider + w/8 >= w/2 - 0.12 || (zslider - w/8 <= 0.12 -w/2 && zinc == -1))
         zinc *= -1;

       glTranslated(0.3, 4*h/30.0 + 0.3, zslider);
       SlidingBox slider;
       slider.initialize(0, 0, 0, l/20, h/15, w/8);
       slider.setColor(0.9, 0.9, 0.9, 1);
       slider.draw();
       glPushMatrix();
        glRotated(-90, 1, 0, 0);
        glColor3d(173.0/255, 1, 47.0/255);
        gluCylinder(gq, 0.05, 0.05, h/1.5 + 0.4, 4, 4);
       glPopMatrix();
       glTranslated(0, h/1.5 + 0.4, 0);
       glRotated(lightfi, 0, 1, 0);
       // searchlight
       lightfi += 2.5;
       while(lightfi >= 360)
         lightfi-=360;
       GLfloat posit[] = {0, 0, 0, 1};
       GLfloat direc[] = {0.0, 0, 1.0, 1.0};
       GLfloat col[] = {170.0/255, 170.0/255, 1, 1.0};
       glLightfv(searchl, GL_POSITION, posit);
       glLightfv(searchl, GL_SPOT_DIRECTION, direc);
       glLightf(searchl, GL_SPOT_CUTOFF, 20.0);
       glLightfv(searchl, GL_DIFFUSE, col);
       gluCylinder(gq, 0.01, 0.4, 0.8, 16, 16);
      glPopMatrix();
     glPopMatrix();
    glPopMatrix();
    gluDeleteQuadric(gq);

  }
};
