#include <GL/glut.h>
#include <GL/glu.h>
#include <GL/gl.h>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <ctime>
#include "glm/glm.h"

#define MAPFILE "1.map"
#define MAX_LIGHT 0.80
#define MIN_LIGHT 0.20
#define RAD(x) (x*M_PI/180.0)
#define INC
#define DEGREE(x) (x*180.0/M_PI)
#include "boxes.cpp"
#include "texloader.cpp"
#include "carframe.cpp"
#include "track.cpp"
#define MAPSIZE 300.0
#define WIN_HEIGHT 700.0
#define WIN_WIDTH 1000.0
#define SIGHT 2.5
#define DRIVER 1
#define ROOF 2
#define SLIDER 3
#define SEARCHLIGHT 4
#define WHEEL 5
#define OVERHEAD 6
#define HELICAM1 7
#define HELICAM2 8
#define REDEEMER 9
#define FRICTION 0.01

Car car, car2;
Map map;
struct timespec Time;
Carframe frame, frame2;
int camera = 0;
bool dragging;
int xstart, ystart;
int shineness;
double fi = 45, camX = 0, camY = 10, pnear, pfar, suntheta, intensity;
double Xstart, Zstart, Xstart2, Zstart2, vel = 0, acc = 0, heliR, heliTheta, heliPhi, heliR2, heliTheta2, heliPhi2;
GLenum cur_shading;
GLfloat sunlight[] = {0.9, 0.9, 0.6, 1};
GLfloat white[] = {1, 1, 1, 1};
GLuint texture_id[10];


void setProject()
{
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(fi, WIN_WIDTH/WIN_HEIGHT, pnear, pfar);
	glMatrixMode(GL_MODELVIEW);
//	glEnable(GL_DEPTH_TEST);
}
void initialize(void)
{
	glClearColor(1,1,1,1);
	glViewport(0, 0, WIN_WIDTH, WIN_HEIGHT);
	/*
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(40, WIN_WIDTH/WIN_HEIGHT,1,600);
	glMatrixMode(GL_MODELVIEW);
	*/
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	//glColorMaterial(GL_FRONT_AND_BACK, GL_DIFFUSE);
	//glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_NORMALIZE);
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_LIGHT2);
	glEnable(GL_LIGHT3);
	glEnable(GL_LIGHT4);
	glEnable(GL_LIGHT5);
	glEnable(GL_LIGHT6);
	
	glEnable(GL_BLEND);
	
//	loadTexture(1,"road.bmp",texture_id);
	loadTexture(1,"sky1.bmp",texture_id);
//	loadTexture(3,"base.bmp",texture_id);
	cur_shading = GL_SMOOTH;
	suntheta = 90.0;
	intensity = MIN_LIGHT + MAX_LIGHT;
	vel = acc = 0;
	Xstart = 60;
	Zstart = -60;
	Xstart2 = 90;
	Zstart2 = -60;
	pnear = 0.4;
	pfar = 1000;
	camX = 250;
	camY = 200;
	heliR = 30;
	heliTheta = 70;
	heliPhi = 90;
	heliR2 = 30;
	heliTheta2 = 70;
	heliPhi2 = 90;
	shineness = 5;
	car.loadmodel();
	car2.loadmodel();
	car.bindlights(GL_LIGHT1, GL_LIGHT3, GL_LIGHT4);
	car2.bindlights(GL_LIGHT2, GL_LIGHT5, GL_LIGHT6);
	clock_gettime(CLOCK_REALTIME, &Time);
	frame.setState(Xstart, Zstart, vel, acc, 90, Time);
	frame.bindCar(&car);
	frame2.setState(Xstart2, Zstart2, vel, acc, 90, Time);
	frame2.bindCar(&car2);
	map.loadmap(MAPFILE);
	dragging = false;
}
void setShading()
{
  glShadeModel(cur_shading);
}

void setLights()
{
  GLfloat sunpos[] = {cos(RAD(suntheta)), sin(RAD(suntheta)), 0, 0};
  intensity = sin(RAD(suntheta))*MAX_LIGHT + MIN_LIGHT;
  GLfloat ambientlight[] = {intensity, intensity, intensity};
  glLightModelfv(GL_AMBIENT, ambientlight);
  glLightfv(GL_LIGHT0, GL_POSITION, sunpos);
  glLightfv(GL_LIGHT0, GL_DIFFUSE, sunlight);
}

void drawtrack()
{
  glPushMatrix();
  //glEnable(GL_TEXTURE_2D);
    GLfloat gray[] = {0.6, 0.6, 0.6, 1};
    glMaterialfv(GL_FRONT, GL_DIFFUSE, gray);
    glMaterialfv(GL_FRONT, GL_AMBIENT, gray);
    //glBindTexture(GL_TEXTURE_2D, texture_id[1]);
    glBegin(GL_QUADS);
      glNormal3f(0, 1, 0);
      //glTexCoord2i(0,0);
      glVertex3f(0, 0, 0);
      //glTexCoord2i(0,1);
      glVertex3f(0, 0, -MAPSIZE);
      //glTexCoord2i(1,1);
      glVertex3f(MAPSIZE, 0, -MAPSIZE);
      //glTexCoord2i(1,0);
      glVertex3f(MAPSIZE, 0, 0);
    glEnd();
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, white);
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, white);
  //glDisable(GL_TEXTURE_2D);
  glPopMatrix();
  map.draw();
}
void drawcar(Car *_car, Carframe *_frame)
{
  if(_car->turning == 0)
  {
    if(_car->steerTheta > 0)
      _car->turn(-1.5);
    else if(_car->steerTheta < 0)
      _car->turn(1.5);
  }
  else if(_car->turning == 1)
  {
    _car->turn(-1);
  }
  else
  {
    _car->turn(1);
  }
  if(fabs(_car->steerTheta) <= 0.4)
    _car->steerTheta = 0;
    _frame->drawCar();
}
void drawaxes()
{
	glColor3d(1, 0, 0);
	glBegin(GL_LINES);
	 glVertex3d(0, 0, 0);
	 glVertex3d(900, 0, 0);
	glEnd();
	
	glColor3d(0, 1, 0);
	glBegin(GL_LINES);
	 glVertex3d(0, 00, 0);
	 glVertex3d(0, 900, 0);
	glEnd();
	
	glColor3d(0, 0, 1);
	glBegin(GL_LINES);
	 glVertex3d(0, 0, 0);
	 glVertex3d(0, 0, 900);
	glEnd();
	
}
/* doesn't work
void writeVel()
{
  glColor3f(79.90/255, 148.0/255, 200.255);
  glRasterPos2d(20, 20);
  char str[50];
  sprintf(str, "Speed : %lf", frame.v);
  //printf("%s\n", str);
  for(int i = 0; str[i] != '\0'; i++)
    glutBitmapCharacter(GLUT_BITMAP_TIMES_ROMAN_24, str[i]);
}
*/
void drawtower()
{
  GLUquadric* gq = gluNewQuadric();
  gluQuadricDrawStyle(gq, GLU_FILL);
  glPushMatrix();
    glTranslated(MAPSIZE/2, 0, -MAPSIZE/2);
    glRotated(-90, 1, 0, 0);
    GLfloat diff[] = {1, 1, 1, 1};
    GLfloat amb[] = {1, 1, 1, 1};
    GLfloat spec[] = {0.9, 0.9, 0.1 , 1};
    glMaterialfv(GL_FRONT, GL_AMBIENT, amb);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, diff);
    glMaterialfv(GL_FRONT, GL_SPECULAR, spec);
    glMaterialf(GL_FRONT, GL_SHININESS, shineness);
    //glMaterialfv(GL_FRONT, GL_AMBIENT, amb);
    gluCylinder(gq, 4, 2, 40, 50, 50);
    glTranslated(0, 0, 44);
    gluSphere(gq, 4, 20, 20);
    
    glMaterialfv(GL_FRONT, GL_AMBIENT, white);
    glMaterialfv(GL_FRONT, GL_DIFFUSE, white);
    glMaterialfv(GL_FRONT, GL_SPECULAR, white);
    glMaterialf(GL_FRONT, GL_SHININESS, 0);
    
  glPopMatrix();
}

void setCamera()
{
  pnear = 0.1;
  pfar = 1000;
  switch (camera)
  {
    		  //gluLookAt(0,0,0,0,-1,-1,0,1,0);
    case 0: gluLookAt(MAPSIZE/2, 100, 0, MAPSIZE/2, 0, -MAPSIZE/2, 0, 1, 0);
	    pnear = 0.01;
	    break;
    case DRIVER : glRotated(1,0,0,1);
		  glRotated(-3, 0, 1, 0);
		  glRotated(5, 1, 0, 0);
                  glRotated(90, 0, 1, 0);
		  glTranslated(-0.1*car.l, -3.5*car.h, -0.25*car.w + 0.2);
                  glRotated(-1*frame.theta, 0, 1, 0);
		  glTranslated(-1*frame.x, 0, -1*frame.z);
		  break;
    case ROOF : glRotated(15, 1, 0, 0);
		glRotated(90, 0, 1, 0);
		glTranslated(-0.05*car.l , -4.5*car.h, -0.25*car.w + 0.2);
		glRotated(-1*frame.theta, 0, 1, 0);
		glTranslated(-1*frame.x, 0, -1*frame.z);
		pnear = 0.3;
		break;
    case SLIDER : glRotated(90, 0, 1, 0);
		  glTranslated( 0.1*car.l - 0.8, -1*(3.7)*car.h - 1.1, -1*car.zslider);
                  glRotated(-1*frame.theta, 0, 1, 0);
		  glTranslated(-1*frame.x, 0, -1*frame.z);
		  pnear = 0.4;
		  break;
    case OVERHEAD: glRotated(15, 1, 0, 0);
		    glRotated(90, 0, 1, 0);
		   glTranslated(0.8*car.l, -7*car.h - 1.1,0);
		   glRotated(-1*frame.theta, 0, 1, 0);
		   glTranslated(-1*frame.x, 0, -1*frame.z);
		   break;
    case SEARCHLIGHT :  glRotated(-5, 1, 0, 0);
			glRotated(180,0,1,0);
			glTranslated(-0.5, 0, 0);
			glRotated(-1*car.lightfi, 0, 1, 0);
			glTranslated(0.1*car.l, -1*(2.9*car.h + car.r + 1.1), -1*car.zslider);
			glRotated(-1*frame.theta, 0, 1, 0);
			glTranslated(-1*frame.x, 0, -1*frame.z);
			pnear = 2;
			break;
    case WHEEL : glRotated(-5, 1, 0, 0);
		 glRotated(90, 0, 1, 0);
		 glRotated(-1*car.steerTheta, 0, 1, 0);
		 glTranslated(-1*(0.4*car.l - car.r - 0.6), -1*(2*car.r + 0.05), -1*(car.w/2 + 0.8));
		 glRotated(-1*frame.theta, 0, 1, 0);
		 glTranslated(-1*frame.x, 0, -1*frame.z);
		 pnear = 1;
		 break;
    case HELICAM1: gluLookAt(frame.x + heliR*sin(RAD(heliTheta))*cos(RAD(heliPhi)), heliR*cos(RAD(heliTheta)), frame.z + heliR*sin(RAD(heliTheta))*sin(RAD(heliPhi)), frame.x, 0, frame.z, 0, 1, 0);
		   pnear = 0.01;
		   break;
    
    case HELICAM2: gluLookAt(frame2.x + heliR2*sin(RAD(heliTheta2))*cos(RAD(heliPhi2)), heliR2*cos(RAD(heliTheta2)), frame2.z + heliR2*sin(RAD(heliTheta2))*sin(RAD(heliPhi2)), frame2.x, 0, frame2.z, 0, 1, 0);
		   pnear = 0.01;
		   break;
    
    case REDEEMER: gluLookAt(MAPSIZE/2, 85, -MAPSIZE + 45, MAPSIZE/2, 0, -MAPSIZE/2, 0, 1, 0);
		   pnear = 5;
		   break;
    
    default: camera = 0;
  }
}
void draw_cylinder()
{

	glPushMatrix();
	glTranslatef(MAPSIZE/2,0,-MAPSIZE/2);
	glPushMatrix();
	GLUquadric *g = gluNewQuadric();
	glEnable(GL_TEXTURE_2D);
	//glEnable(GL_COLOR_MATERIAL);
	glBindTexture(GL_TEXTURE_2D,texture_id[1]);
	gluQuadricTexture(g,GL_TRUE);
  	glColor4fv(white);
	//gluQuadricDrawStyle(g, GLU_FILL);
	glRotatef(-90,1,0,0);
//	gluCylinder(g,50,50,60,50,50);
	gluCylinder(g,MAPSIZE/1.414 -58,MAPSIZE/1.414 - 58,300,50,50);


	glDisable(GL_TEXTURE_2D);
	//glDisable(GL_COLOR_MATERIAL);
	glPopMatrix();
	glPopMatrix();
	gluDeleteQuadric(g);

}



void draw(void)
{
	float centre = MAPSIZE/2;
	setProject();
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
	glLoadIdentity();
	setCamera();
	bool collision = false;
	float oldz = frame.z, oldx = frame.x, oldtheta = frame.theta;
	clock_gettime(CLOCK_REALTIME, &Time);
	if(frame.v != 0 || frame.a != 0)
	  frame.move(Time);
	
	for(int i = 0; i < map.N; i ++)
	{
		if(map.arr[i].permeable)
			continue;
	  if(frame.x + (car.l + car.w)/4 >= map.arr[i].X1 && frame.x - (car.l + car.w)/4 <= map.arr[i].X2 && frame.z + (car.l + car.w)/4 >= map.arr[i].Z1 && frame.z - (car.l + car.w)/4 <= map.arr[i].Z2)
	  {
	    collision = true;
	    break;
	  }
	}
	centre = MAPSIZE/2;
	if(sqrt((frame.x - centre)*(frame.x - centre) + (frame.z + centre)*(frame.z + centre)) <= (car.l + car.w)/4)
	{
		collision = true;
	}

	if(collision)
	{
	  frame.setState(oldx, oldz, 0, 0, oldtheta, Time);
	}
	drawcar(&car, &frame);
	
	collision = false;
	oldz = frame2.z, oldx = frame2.x, oldtheta = frame2.theta;
	clock_gettime(CLOCK_REALTIME, &Time);
	if(frame2.v != 0 || frame2.a != 0)
	  frame2.move(Time);
	
	for(int i = 0; i < map.N; i ++)
	{
		if(map.arr[i].permeable)
			continue;
	  if(frame2.x + (car2.l + car2.w)/4 >= map.arr[i].X1 && frame2.x - (car2.l + car2.w)/4 <= map.arr[i].X2 && frame2.z + (car2.l + car2.w)/4 >= map.arr[i].Z1 && frame2.z - (car2.l + car2.w)/4 <= map.arr[i].Z2)
	  {
	    collision = true;
	    break;
	  }
	}

	if(sqrt((frame2.x - centre)*(frame2.x - centre) + (frame2.z +centre)*(frame2.z + centre)) <= (car2.l + car2.w)/2)
	{
		collision = true;
	}
	if(collision)
	{
	  frame2.setState(oldx, oldz, 0, 0, oldtheta, Time);
	}
	drawcar(&car2, &frame2);
	setShading();
	setLights();
	//drawaxes();
	draw_cylinder();
	drawtower();
	drawtrack();
	glutSwapBuffers();
	//fflush(stdout);
}

void keyrelease(unsigned char key, int , int)
{
  if(key == 'w' || key == 's')
  {
    if(frame.v < 0)
	  frame.a = FRICTION;
	else if(frame.v > 0)
	  frame.a = -FRICTION;
  }
  if(key == 'a' || key == 'd')
  {
    car.turning = 0;
  }
}

void specrelease(int key, int , int)
{
  if(key == GLUT_KEY_UP || key == GLUT_KEY_DOWN)
  {
    if(frame2.v < 0)
	  frame2.a = FRICTION;
	else if(frame.v > 0)
	  frame2.a = -FRICTION;
  }
  if(key == GLUT_KEY_LEFT || key == GLUT_KEY_RIGHT)
  {
    car2.turning = 0;
  }
}

void keyboard (unsigned char key, int x1, int y1) {
	if (key == 27)
	  exit(0);
	else if (key >= '0' && key <= '9') {
	        fi = 50;
		camera = key - '0';
	}
	else if (key == 'w')
	{
	  if(frame.v < 0)
	   frame.a = 1.6;
	  else
	   frame.a = 0.8;
	}
	else if (key == 's')
	{
	  if(frame.v > 0)
	    frame.a = -1.6;
	  else
	    frame.a = -0.8;
	}
	else if (key == 'a')
	{
	  car.turning = -1;
	}
	else if (key == 'd')
	{
	  car.turning = +1;
	}
	else if (key == ',' && suntheta < 175)
	{
	  suntheta += 1;
	}
	else if (key == '.' && suntheta > 5)
	{
	  suntheta -= 1;
	}
	else if ( key == 'f')
	{
	  cur_shading = (cur_shading == GL_FLAT) ? GL_SMOOTH : GL_FLAT;
	}
	else if (key == '+' && shineness <= 100)
	{
	  shineness ++;
	}
	else if (key == '-' && shineness >= 2)
	{
	  shineness --;
	}
}
void mouse(int but, int s, int xx, int yy)
{
  if(camera != HELICAM1 && camera != HELICAM2)
  {
    dragging = false;
    return;
  }
  double *r;
  if(camera == HELICAM1)
    r = &heliR;
  else
    r = &heliR2;
    
  if(but == 0 && s == GLUT_DOWN)
  {
    dragging = true;
    xstart = xx;
    ystart = yy;
  }
  else if(but == 0 && s == GLUT_UP)
  {
    dragging = false;
  }
  else if(but == 3)
  {
    *r -= 0.1;
  }
  else if(but == 4)
  {
    *r += 0.1;
  }
}
void dragHandler(int xx, int yy)
{
  double *th;
  double *phi;
  if(camera == HELICAM1)
  {
    th = &heliTheta;
    phi = &heliPhi;
  }
  else
  {
    th = &heliTheta2;
    phi = &heliPhi2;
  }
  
  if(dragging)
  {
    *th -= 0.05*(yy - ystart);
    if(*th < 10)
      *th = 10;
    if(*th > 80)
      *th = 80;
    *phi += 0.05*(xx - xstart);
  }
}

void special(int key, int xx, int yy)
{
	if (key == GLUT_KEY_UP)
	{
	  if(frame2.v < 0)
	   frame2.a = 1.6;
	  else
	   frame2.a = 0.8;
	}
	else if (key == GLUT_KEY_DOWN)
	{
	  if(frame2.v > 0)
	    frame2.a = -1.6;
	  else
	    frame2.a = -0.8;
	}
	else if (key == GLUT_KEY_LEFT)
	{
	  car2.turning = -1;
	}
	else if (key == GLUT_KEY_RIGHT)
	{
	  car2.turning = +1;
	}
}

int main(int argc,char **argv)
{
	glutInit(&argc,argv);
	glutInitWindowSize(WIN_WIDTH, WIN_HEIGHT);
	glutInitWindowPosition(0,0);
	glutInitDisplayMode(GLUT_RGBA | GLUT_DEPTH | GLUT_DOUBLE);
	glutCreateWindow("car");
	glutDisplayFunc(draw);
	glutIdleFunc(draw);
	glutSpecialFunc(special);
	glutKeyboardFunc(keyboard);
	glutKeyboardUpFunc(keyrelease);
	glutSpecialUpFunc(specrelease);
	glutMouseFunc(mouse);
	glutMotionFunc(dragHandler);
  //glutFullScreen();
	initialize();
	glutMainLoop();
	return 0;
}
