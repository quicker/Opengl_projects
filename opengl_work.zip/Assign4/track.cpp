#include "objects.cpp"
#include <cstdio>
#include <cstring>
class Map
{
public:
  Block arr[10000];
  int N;
  void loadmap(char filename[50])
  {
    int x1, x2, z1, z2;
    float sx, sz;
    float ht;
    int perm;
    char option[5];
    char objfile[20];
    FILE *fp = fopen(filename, "rb");
    if(fp == NULL)
    {
      fprintf(stderr, "Error: mapfile not found\n");
      return;
    }
    fscanf(fp, "%d", &N);
    for(int i=0; i<N; i++)
    {
      fscanf(fp, "%d %d %d %d %f %d", &x1, &x2, &z1, &z2, &ht, &perm);
  //    fscanf(fp, "%f %f", &sx, &sz);
    //  fscanf(fp, "%d", &perm);
      fscanf(fp, "%s", option);
      arr[i].permeable = perm;
     // arr[i].setscale(sx, sz);
      arr[i].settype(option);
      
      fscanf(fp, "%s", objfile);
      arr[i].place(x1, x2, z1, z2, ht);
      arr[i].bindModel(objfile);
    }
    fclose(fp);
//    printf("Loaded map\n");
  }
  void draw()
  {
    for(int i = 0; i < N; i ++)
    {
      arr[i].draw();
    }
  }
};
