//everything is in X-Z plane, thus four values of X1,X2,Z1,Z2 will be sufficient to define objects.
// convention for object, X1 < X2 and same for Zs
#ifndef INC
#include <GL/glut.h>
#endif
#include <cstring>
#include <algorithm>
using namespace std;

class Block
{
public:
  float X1, X2, Z1, Z2, HT, sx, sz;
  char type[5];
  int permeable;
  GLMmodel* model;
  GLuint tex_id[10];
  int tex_n;

  Block()
  {
	  permeable = 0;
    tex_n = 0;
  };
  void place(float x1, float x2, float z1, float z2, float ht)
  {
	  X1 = min(x1, x2);
	  X2 = max(x1, x2);
	  Z1 = min(z1, z2);
	  Z2 = max(z1, z2);
	  HT = ht;
  }
  void setscale(float x, float z)
  {
	  sx = x;
	  sz = z;
  }
  void settype(char opt[])
  {
    strcpy(type, opt);
  }
  
  void bindModel(char filename[50])
  {
    if(!strcmp(type, "OBJ"))
    {
      model = glmReadOBJ(filename);
      glmUnitize(model);
      glmFacetNormals(model);
      glmVertexNormals(model, 90.0, true);
    }
    else if(!strcmp(type, "TEX"))
    {
      loadTexture(tex_n++, filename, tex_id);
    }
  }
  
  bool check_intersect(float x1, float z1, float x2, float z2, float x3, float z3, float x4, float z4)
  {
    float minx = min(x1, min(x2, min(x3, x4)));
    float maxx = max(x1, max(x2, max(x3, x4)));
    float minz = min(z1, min(z2, min(z3, z4)));
    float maxz = max(z1, max(z2, max(z3, z4)));
    if( maxz <= Z1 || minz >= Z2 || maxx <= X1 || minx >= X2 )
      return false;
    else
      return true;
  }
  void setperm(int p)
  {
	  permeable = p;
  }  
  void draw()
  {
    glPushMatrix();
      glTranslated((X1+X2)/2, HT, (Z1 + Z2)/2);

      if(!strcmp(type, "OBJ"))
      {
        glEnable(GL_COLOR_MATERIAL);
        glScalef(30, 30, 30); 
        glmDraw(model, GLM_SMOOTH | GLM_TEXTURE | GLM_MATERIAL);
        glDisable(GL_COLOR_MATERIAL);
      }
      else if(!strcmp(type, "TEX"))
      {
	glColor3f(1,1,1);
	int wid = Z2 - Z1, len = X2 - X1;
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, tex_id[0]);
	glBegin(GL_QUADS);
	  glNormal3f(0,1,0);
	  glTexCoord2i(0, 0);
	  glVertex3f(-len/2, 0, -wid/2);
	  glTexCoord2i(0, 1);
	  glVertex3f(-len/2, 0, wid/2);
	  glTexCoord2i(1, 1);
	  glVertex3f(len/2, 0, wid/2);
	  glTexCoord2i(1, 0);
	  glVertex3f(len/2, 0, -wid/2);
	glEnd();
	glDisable(GL_TEXTURE_2D);
      }

    glPopMatrix();
        // change code to draw whatever object is assigned to this block.
	/*	   
	  int w = Z2 - Z1, h = 20, l = X2 - X1;
	  glPushMatrix();
	    glTranslatef((X1 + X2)/2, h/2, (Z1 + Z2)/2);
	    glColor3f(0, 1, 0);
	    glPushMatrix();
	      glTranslatef(l/2, 0, 0);
	      glBegin(GL_QUADS);
	        glVertex3f(0, -h/2, -w/2);
		glVertex3f(0, -h/2, w/2);
		glVertex3f(0, h/2, w/2);
		glVertex3f(0, h/2, -w/2);
	      glEnd();
	    glPopMatrix();
	    glPushMatrix();
	      glTranslatef(-l/2, 0, 0);
	      glBegin(GL_QUADS);
	        glVertex3f(0, -h/2, -w/2);
		glVertex3f(0, -h/2, w/2);
		glVertex3f(0, h/2, w/2);
		glVertex3f(0, h/2, -w/2);
	      glEnd();
	    glPopMatrix();
	    glPushMatrix();
	      glTranslatef(0, h/2, 0);
	      glBegin(GL_QUADS);
	        glVertex3f(-l/2, 0, -w/2);
		glVertex3f(-l/2, 0, w/2);
		glVertex3f(l/2, 0, w/2);
		glVertex3f(l/2, 0, -w/2);
	      glEnd();
	    glPopMatrix();
	    glPushMatrix();
	      glTranslatef(0, 0, w/2);
	      glBegin(GL_QUADS);
	        glVertex3f(-l/2, -h/2, 0);
		glVertex3f(-l/2, h/2, 0);
		glVertex3f(l/2, h/2, 0);
		glVertex3f(l/2, -h/2, 0);
	      glEnd();
	    glPopMatrix();
	    glPushMatrix();
	      glTranslatef(0, 0, -w/2);
	      glBegin(GL_QUADS);
	        glVertex3f(-l/2, -h/2, 0);
		glVertex3f(-l/2, h/2, 0);
		glVertex3f(l/2, h/2, 0);
		glVertex3f(l/2, -h/2, 0);
	      glEnd();
	    glPopMatrix();
	  glPopMatrix();
	  */ 
  }
};
