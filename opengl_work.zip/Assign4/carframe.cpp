#ifndef INC
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <cmath>
#include <ctime>
#define RAD(x) (x*M_PI/180)
#define DEGREE(x) (180*x/M_PI)
#include "boxes.cpp"
#endif
#define TOPSPEED 35
#define THRESH_V 0.01

long long timediffn(struct timespec t1, struct timespec t2)
{
    long long diff = 0;
    long long t1s = t1.tv_sec, t2s = t2.tv_sec;
    diff = t2.tv_nsec - t1.tv_nsec;
    if(diff < 0)
    {
      diff += 1000000000;
      t2s --;
    }
    diff += t2s - t1s;
    return diff;
}

class Carframe            // a frame that moves in the x-z plane.
{
  public:
  double x, z, v, a, theta;   // theta in degrees is the angle the frame makes with its initial orientation.
  struct timespec t;
  Car* car;
  
  void bindCar(Car* c)
  {
    car = c;
  }
  void drawCar()
  {
    while(theta < 0)
      theta += 360;
    while(theta >= 360)
      theta -= 360;
    glPushMatrix();
      glTranslated(x, 0, z);
      glRotated(theta, 0, 1, 0);
      
      car->draw();
    glPopMatrix();
  }
  
  void setState(double X, double Z, double V, double A, double T, struct timespec tm)
  {
    v = V;
    a = A;
    x = X;
    //y = Y;
    z = Z;
    theta = T;
    t = tm;
  }
  void stop()
  {
    v = a = 0;
  }
  void move(struct timespec t2)
  {
    long long dt = timediffn(t, t2);
    
    double DT = (dt*1.0)/1000000000.0;
    //printf("vel %f\n", v);
    x = x + v*cos(RAD(theta))*DT;
    z = z - v*sin(RAD(theta))*DT;
    theta += (car->steerTheta)*v*DT;
    t = t2;
    if(fabs(v) <= TOPSPEED || v*a <= 0)
      v = v + a*DT;
    if(fabs(v) < THRESH_V && v*a <= 0)
    {
      //printf("have to stop!!\n");
      stop();
    }
    car->wheelTheta -= DEGREE(v*DT/(car->wheelR));
    while(car->wheelTheta < 0)
      car->wheelTheta += 360.0;
  }
};
